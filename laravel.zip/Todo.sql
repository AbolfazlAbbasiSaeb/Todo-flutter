-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 22, 2023 at 06:31 PM
-- Server version: 5.7.36-cll-lve
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `abolfa35_todo`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `user_id`, `status`, `created_at`, `updated_at`) VALUES
(28, 'طراحی سایت فروشگاهی', '17', '0', '2023-04-17 10:30:38', '2023-04-17 10:32:31'),
(29, 'New', '17', '0', '2023-04-17 10:52:38', '2023-04-17 10:52:38'),
(30, 'طراحی سایت فروشگاهی', '18', '0', '2023-04-22 10:23:41', '2023-04-22 10:24:20');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2023_03_03_173135_create_products_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 2, 'Laravel Password Grant Client', 'eb4b14e7c8e01b37db5faab752754e4e38f32e85dce67fde52fd86d1f98f4c5b', '[\"*\"]', NULL, NULL, '2023-04-13 11:12:20', '2023-04-13 11:12:20'),
(2, 'App\\Models\\User', 3, 'Laravel Password Grant Client', '0a2f500e73780617030a3fc7f83511d92795713c7c67c3c7ccf9188f658b9803', '[\"*\"]', NULL, NULL, '2023-04-13 11:27:33', '2023-04-13 11:27:33'),
(3, 'App\\Models\\User', 4, 'Laravel Password Grant Client', 'b9df8093a20b4d2c7e96a3ab2f8e38ba331f7a6c8d827ce23a3b53704c5c097f', '[\"*\"]', NULL, NULL, '2023-04-13 11:41:24', '2023-04-13 11:41:24'),
(4, 'App\\Models\\User', 7, 'auth_token', '0ad1e13e77c5369f32d267360d21a210d1b78ad82b56a433a20d8b5df15a2423', '[\"*\"]', '2023-04-13 11:49:38', NULL, '2023-04-13 11:48:11', '2023-04-13 11:49:38'),
(5, 'App\\Models\\User', 8, 'auth_token', '2ac506fa07b38edeccb6cd18dd70b5479f319676c11105e810f860f88dade0b5', '[\"*\"]', NULL, NULL, '2023-04-13 12:17:51', '2023-04-13 12:17:51'),
(6, 'App\\Models\\User', 9, 'auth_token', '6cb832d72b12963b684cea048c57060958063795b3c39a0b7317693a97d56d37', '[\"*\"]', NULL, NULL, '2023-04-13 12:19:19', '2023-04-13 12:19:19'),
(7, 'App\\Models\\User', 10, 'auth_token', '1aea03e93f55f6af1b17b36652e67c89f9c0e4e35035805d491530293ac135aa', '[\"*\"]', NULL, NULL, '2023-04-13 12:29:53', '2023-04-13 12:29:53'),
(8, 'App\\Models\\User', 11, 'auth_token', '3b8186d5d97536451597774d1d20f3b2c8b9967e518fe27c18ea292c2462d0c4', '[\"*\"]', NULL, NULL, '2023-04-13 12:32:46', '2023-04-13 12:32:46'),
(9, 'App\\Models\\User', 12, 'auth_token', 'e3941cc4dd2dbf552dec760964a977cf8f16e544b6ef63982b99e2a49ae47d35', '[\"*\"]', NULL, NULL, '2023-04-13 12:33:33', '2023-04-13 12:33:33'),
(10, 'App\\Models\\User', 13, 'auth_token', 'f4142a949c07763878020548423e8a5858ab5eccf5f82a7e33e87de4dab5ac8c', '[\"*\"]', NULL, NULL, '2023-04-13 12:34:51', '2023-04-13 12:34:51'),
(11, 'App\\Models\\User', 14, 'auth_token', 'e8b2457008d98c4af00ecba8ae875d33370e959ea6c1071c497b69b55702aaad', '[\"*\"]', NULL, NULL, '2023-04-13 12:45:16', '2023-04-13 12:45:16'),
(12, 'App\\Models\\User', 1, 'auth_token', '5c89ca56b80af2ad76d28aaaff76120f8f1455bf06f2f3c47ca1152b370c7954', '[\"*\"]', NULL, NULL, '2023-04-13 14:37:53', '2023-04-13 14:37:53'),
(13, 'App\\Models\\User', 2, 'auth_token', '3c78cf96d5323323b0c6ba099c1a8e749308a8b6014b039b2c86068b794273c7', '[\"*\"]', NULL, NULL, '2023-04-13 14:45:07', '2023-04-13 14:45:07'),
(14, 'App\\Models\\User', 3, 'auth_token', 'fd8f26c7e57b87cf85ae7e43129222ed8503b41383fb8d2bc8ffae6b97e06ac5', '[\"*\"]', NULL, NULL, '2023-04-13 14:58:54', '2023-04-13 14:58:54'),
(15, 'App\\Models\\User', 4, 'auth_token', 'eb8cabb9b23e8930c2b0bb64dbccabf1839e5c8ce3d311e3eae41803e05cc95c', '[\"*\"]', NULL, NULL, '2023-04-13 15:00:08', '2023-04-13 15:00:08'),
(16, 'App\\Models\\User', 5, 'auth_token', '9cfce3fab796feffef961efb586eed64dd19579fba5ccff6605b72a272c34a5f', '[\"*\"]', NULL, NULL, '2023-04-13 15:03:31', '2023-04-13 15:03:31'),
(17, 'App\\Models\\User', 5, 'Laravel Password Grant Client', '52e2740bba906f1f4196192c426acf5e3df4503c251e4505e2f01e8efb39c315', '[\"*\"]', NULL, NULL, '2023-04-13 15:56:39', '2023-04-13 15:56:39'),
(18, 'App\\Models\\User', 5, 'auth_token', 'b8774426724ef759e16d04fd8ab6f975fb8c4dac7e1250317e4c57374c44bbf1', '[\"*\"]', NULL, NULL, '2023-04-13 15:58:59', '2023-04-13 15:58:59'),
(19, 'App\\Models\\User', 5, 'auth_token', '168936b2118dfdfbeb37eac143aa6892fcdaa2b35f1013a4efe18f8af079356b', '[\"*\"]', '2023-04-21 18:52:12', NULL, '2023-04-13 16:00:09', '2023-04-21 18:52:12'),
(20, 'App\\Models\\User', 6, 'auth_token', '1f9a4896e06c6fdaaf9ad70cf7fbc2a4b1f4241c2c4c4f420bf851cd574dacdc', '[\"*\"]', '2023-04-22 10:33:10', NULL, '2023-04-16 16:48:52', '2023-04-22 10:33:10'),
(21, 'App\\Models\\User', 7, 'auth_token', '8428a85d554d8f3d9f3875c3b0b19e7a7060b5cbd0b52d5c2866c054780ab7ab', '[\"*\"]', '2023-04-21 18:53:31', NULL, '2023-04-21 18:53:30', '2023-04-21 18:53:31'),
(22, 'App\\Models\\User', 8, 'auth_token', '797a1660e6aa565ae29c53c4a5c74ba1568e9de499dcb8a12961338f1fc40825', '[\"*\"]', '2023-04-21 18:56:00', NULL, '2023-04-21 18:55:59', '2023-04-21 18:56:00'),
(23, 'App\\Models\\User', 9, 'auth_token', 'de7fa4d96436eb8bd040c95fd0908a0efe28d2ee43ec659b9b0e643c8a49e21f', '[\"*\"]', '2023-04-21 18:58:24', NULL, '2023-04-21 18:58:23', '2023-04-21 18:58:24'),
(24, 'App\\Models\\User', 10, 'auth_token', '7fbcb058f57546f0f823bc9c0e0df4ef4a359fb00e5a883fa1268418832391e6', '[\"*\"]', '2023-04-21 18:59:13', NULL, '2023-04-21 18:59:12', '2023-04-21 18:59:13'),
(25, 'App\\Models\\User', 11, 'auth_token', 'bfd75c9cbca640269061cee61df64f05b3a7a0429bb562f6e77460ca69dfc45d', '[\"*\"]', '2023-04-21 18:59:51', NULL, '2023-04-21 18:59:51', '2023-04-21 18:59:51'),
(26, 'App\\Models\\User', 12, 'auth_token', '8ff869d0e19c77ab0242dce03a32074dbc90cef6cf8d1ebd40bc0f40ef49c523', '[\"*\"]', '2023-04-21 19:01:35', NULL, '2023-04-21 19:01:34', '2023-04-21 19:01:35'),
(27, 'App\\Models\\User', 13, 'auth_token', 'cd564238cc59a7650aba55e564fd4f38b4e24d4f7c615b791e1c95da7654508c', '[\"*\"]', '2023-04-22 10:06:27', NULL, '2023-04-22 10:06:27', '2023-04-22 10:06:27'),
(28, 'App\\Models\\User', 14, 'auth_token', '4c708bd9744b2f277c0774ca267dd9baa5af71c196def20ee005253bf93ba081', '[\"*\"]', '2023-04-22 10:09:08', NULL, '2023-04-22 10:09:08', '2023-04-22 10:09:08'),
(29, 'App\\Models\\User', 15, 'auth_token', '9effb138c7f93b75dbed8fcf82494b64d324cf338ec50f9c207de7d6d66392e8', '[\"*\"]', '2023-04-22 10:10:48', NULL, '2023-04-22 10:10:48', '2023-04-22 10:10:48'),
(30, 'App\\Models\\User', 16, 'auth_token', '5235cc25193a986df504664ed105984ae4aeed1f36dac281ef77616af7549e97', '[\"*\"]', '2023-04-22 10:12:43', NULL, '2023-04-22 10:12:42', '2023-04-22 10:12:43'),
(31, 'App\\Models\\User', 17, 'auth_token', '83894036723c0e996decd95da30ea0ac78b1b9361f68042ee0b9214cabedb243', '[\"*\"]', '2023-04-22 10:13:25', NULL, '2023-04-22 10:13:25', '2023-04-22 10:13:25'),
(32, 'App\\Models\\User', 18, 'auth_token', '9927b210fb239181d38fa6bbfc5fa73cc8ba6a5e43ec39968ee222af3ff71388', '[\"*\"]', '2023-04-22 10:23:41', NULL, '2023-04-22 10:22:20', '2023-04-22 10:23:41'),
(33, 'App\\Models\\User', 18, 'auth_token', '3373819a9daa0fddee93f57498642fc2e0babf8965d055ee6fe69f0566864a87', '[\"*\"]', '2023-04-22 11:24:32', NULL, '2023-04-22 10:28:36', '2023-04-22 11:24:32'),
(34, 'App\\Models\\User', 18, 'auth_token', '8d588257f435c2fb0603c8bca2a103b666a15acb3329feba66886f8589f9c79c', '[\"*\"]', '2023-04-22 11:19:21', NULL, '2023-04-22 10:34:19', '2023-04-22 11:19:21');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(8,2) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `todos`
--

CREATE TABLE `todos` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `category_id` varchar(60) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(60) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `todos`
--

INSERT INTO `todos` (`id`, `title`, `description`, `category_id`, `updated_at`, `status`, `created_at`) VALUES
(2, 'تایید', 'انجام دادن صفحه لاگین تست دوم', '1', '2023-04-17 19:56:18', '0', '0000-00-00 00:00:00'),
(9, 'تایید', 'انجام دادن صفحه لاگین تست دومیبیسبسیب', '1', '2023-04-17 19:56:18', '1', '0000-00-00 00:00:00'),
(16, 'طراحی سایت1', 'تست توضیحات', '28', '2023-04-21 18:44:38', '2', '2023-04-17 17:17:34'),
(19, 'صفحه ورود', 'ورود با شماره موبایل و با کد تایید', '30', '2023-04-22 10:35:02', '1', '2023-04-22 10:25:13'),
(20, 'صفحه ثبت نام', 'فیلد نام - نشانی- شماره تلفن-', '30', '2023-04-22 10:27:28', '2', '2023-04-22 10:26:28'),
(22, 'صفحه ایجاد تیکت', 'صفحه ایجاد تیکت با توضیحات', '30', '2023-04-22 11:21:11', '0', '2023-04-22 11:21:11'),
(23, 'صفحه مشاهده تیکت', 'صفحه مشاهده تیکت کاربر', '30', '2023-04-22 11:21:38', '0', '2023-04-22 11:21:38');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'ابوالفظل عباسی', '09120396189', 'abolfazlabasi1999@gmail.com', NULL, '$2y$10$oZ5UkclAGDdLPicCrLF2xOM4V/wvdNlEhaPGh.MyDdC6lfj/dVu9G', NULL, '2023-04-13 14:37:53', '2023-04-13 14:37:53'),
(2, 'ali', '09126546546546', 'ali@alio.com', NULL, '$2y$10$HqejvGou2GpavK5noBJWbOw6RKT2nxs6hP0XKOgSqqQzzUvZzfDmy', NULL, '2023-04-13 14:45:07', '2023-04-13 14:45:07'),
(3, 'reza', '091231321321', 'reza@reza.com', NULL, '$2y$10$Ap1yJLWng4jb/W5uS3qCG./VXH2viW9UhqpnT/IR9yoggbg2aipAq', NULL, '2023-04-13 14:58:54', '2023-04-13 14:58:54'),
(4, 'abolfazl', '091231654654', 'abolfazl@a.com', NULL, '$2y$10$u3wsAiIjuFsXhRC5LA3tYeEZLDjsKym9SozEq.abBoVZ2BHy7CzxC', NULL, '2023-04-13 15:00:08', '2023-04-13 15:00:08'),
(5, 'abolfazl Abbasi', '0923132165', 'abolfazl@b.com', NULL, '$2y$10$yHRsUZJBwn.DYN4iZ03pqORCPS3gxN.7GuQ0.wHfsVG0HVtUtEZVy', NULL, '2023-04-13 15:03:31', '2023-04-13 15:03:31'),
(6, 'abolfazl', '465465465465', 'abolfazlsadsadasd@fsdfsd.com', NULL, '$2y$10$wHCBpB7R0JdU8a7yrvbWrOuwdS8NuBRgocHhiBIhILlCCv1zDqVCm', NULL, '2023-04-16 16:48:52', '2023-04-16 16:48:52'),
(7, 'abolfazl', '6465465465465', 'abolfazl@k.com', NULL, '$2y$10$dV0eX4aO39wCmL/bOWtEKes4V1EC7wqSmzYCRiC5jKCQK0e3lvoa2', NULL, '2023-04-21 18:53:30', '2023-04-21 18:53:30'),
(8, 'dsfdsfd', '434534', 'dffsfsd@sdfsdf.cc', NULL, '$2y$10$R186h2JZ64lD0A2O0cNf3OZBt29AunniMFbJl7KI7TmAPJdmSfaUW', NULL, '2023-04-21 18:55:59', '2023-04-21 18:55:59'),
(9, 'fferwer', '43535453', 'sdfdsf@dfsfsdf.cc', NULL, '$2y$10$EUV8ehgAlUx9eq8fMfNXQuvqpu23XRxueC/9hj5Pq8CSIioqcmcw2', NULL, '2023-04-21 18:58:23', '2023-04-21 18:58:23'),
(10, 'fdssdfsd', '3425254', 'fsdfsdfds@dsdasd.cc', NULL, '$2y$10$A0iJWQlCwaLFsceUo1uFbO.gBQLoQ2c0SGlPAtZpcbUgttKHa48w6', NULL, '2023-04-21 18:59:12', '2023-04-21 18:59:12'),
(11, 'fdsfsdf', '345435435', 'sddsadas@dddd.cc', NULL, '$2y$10$j/piZfRBkmeIXjfDOkImD.Rnsjy5GFZRliX3WGNfud7bYr07JlK5q', NULL, '2023-04-21 18:59:51', '2023-04-21 18:59:51'),
(12, 'fdsfsdf', '4534534', 'fdsfsdfs@fdsfdsd.cc', NULL, '$2y$10$F.nIMFmiwrtwhIeKrwWcye2/ho1NZrIP6LvY6tzQPCG6yByE1IO.q', NULL, '2023-04-21 19:01:34', '2023-04-21 19:01:34'),
(13, 'test', '42343223', 'adasads@dad.cc', NULL, '$2y$10$p.cuxPO3V0r5Ah42VKLchuO6TRyNJIOmFZPkpLlqRPBNlutrzFkca', NULL, '2023-04-22 10:06:27', '2023-04-22 10:06:27'),
(14, 'sadas', '3432432', 'dffdsfs@fdsf.ff', NULL, '$2y$10$SQ7lweD0QfUE8CjQXjcvxuC0b2.t7ikXpeM/pDq0/0sfCIDWU1CSG', NULL, '2023-04-22 10:09:08', '2023-04-22 10:09:08'),
(15, 'dsadasd', '32423442', 'dasdasds@fsfs.dd', NULL, '$2y$10$64S2QUfhpaYW5lYy0EIO9uOX/Fkcqc8VvyFV.1j9oNf1CMYb66w4a', NULL, '2023-04-22 10:10:48', '2023-04-22 10:10:48'),
(16, 'fsfdsfs', '45354353', 'fdsggfdgdf@fsdfsd.cc', NULL, '$2y$10$f1YikPaq0MlnEjeVeGymke9CGgOIHd.fWZ7KmMs3opW/WMAj68fMe', NULL, '2023-04-22 10:12:42', '2023-04-22 10:12:42'),
(17, 'fsdf', '5345345', 'fsdfds@fsdfd.cc', NULL, '$2y$10$6NoJHA2B4FV2SNKQr1OKz..WXD3JRD4ck6wHG8JgXPq/D0CbN.Ruy', NULL, '2023-04-22 10:13:25', '2023-04-22 10:13:25'),
(18, 'abolfazl', '09126546565', 'abolfazll@l.com', NULL, '$2y$10$glXBCdV7cHj1st84H.Mf9eYq1bwq.xPYBaU8eqaxT8tatQPtGS5A2', NULL, '2023-04-22 10:22:20', '2023-04-22 10:22:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `todos`
--
ALTER TABLE `todos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `todos`
--
ALTER TABLE `todos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
