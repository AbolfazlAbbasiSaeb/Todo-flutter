
<?php $__env->startSection('header'); ?>
    <!-- BEGIN THEME GLOBAL STYLES -->
    <link href="<?php echo e(asset('src/plugins/src/noUiSlider/nouislider.min.css')); ?>" rel="stylesheet" type="text/css">
    <!-- END THEME GLOBAL STYLES -->

    <!--  BEGIN CUSTOM STYLE FILE  -->
    <link href="<?php echo e(asset('src/assets/css/light/scrollspyNav.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('src/plugins/css/light/noUiSlider/custom-nouiSlider.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('src/plugins/css/light/bootstrap-range-Slider/bootstrap-slider.css')); ?>" rel="stylesheet" type="text/css">

    <link href="<?php echo e(asset('src/assets/css/dark/scrollspyNav.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('src/plugins/css/dark/noUiSlider/custom-nouiSlider.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('src/plugins/css/dark/bootstrap-range-Slider/bootstrap-slider.css')); ?>" rel="stylesheet" type="text/css">
    <!--  END CUSTOM STYLE FILE  -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('panel'); ?>
<div class="middle-content container-xxl p-0">
    
                    <div class="row layout-spacing pt-3">
						<div class="col-lg-12 col-sm-12 col-12 layout-spacing">
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">                                
                                    <div class="row">
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                            <h4>اطلاعات سرویس</h4>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area">
                                <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                                    <form action="<?php echo e(route('admin.products.store')); ?>" method="POST" class="row w-100" enctype="multipart/form-data">

										<?php echo csrf_field(); ?>
										<div class="col-lg-4 my-auto">
											<label for="name">عنوان محصول</label>
										</div>
										<div class="col-lg-8">
											<div class="input-group mb-3">
                                        		<input type="text" id="name" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="عنوان" name="name">
											</div>
										</div>
										<div class="col-lg-4 my-auto">
											<label for="category">دسته</label>
										</div>
										<div class="col-lg-8">
											<div class="input-group mb-3">
												<select class="form-select " name="category_id" id="category">
													<option disabled selected>دسته</option>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id') == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													
												</select>
											</div>
										</div>
										<div class="col-lg-4 my-auto">
											<label for="price">قیمت</label>
										</div>
										<div class="col-lg-8">
											<div class="input-group mb-3">
												<input type="text" name="price" value="<?php echo e(old('price')); ?>" class="form-control" id="price">
												<span class="input-group-text">تومان</span>
											</div>
										</div>
										<div class="col-lg-4 my-auto">
											<label for="descriptions">توضیحات</label>
										</div>
										<div class="col-lg-8">
											<div class="input-group">
                                            <textarea class="form-control" id="description" name="description" rows="5"><?php echo e(old('description')); ?></textarea>
											</div>
										</div>
                                        <div class="col-lg-4 my-auto">
											<label for="descriptions">تصویر</label>
										</div>
										<div class="col-lg-8">
											<div class="input-group">
                                            <input type="file" class="form-control-file" id="image" name="image">
											</div>
										</div>
										
										<div class="col-lg-4 my-2">
                                        <button type="submit" class="btn btn-primary">ذخیره</button>
										</div>
									</form>

                                </div>
                            </div>
                        </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<script src="<?php echo e(asset('assets/js/jquery-3.6.3.min.js')); ?>"></script>
	<script>
		$('#category').on('change',function(){
			if($(this).find(':selected').attr("data-type") == 1){
				$('.size-box').slideDown();
				$('.duration-box').slideUp();
			} else {
				$('.duration-box').slideDown();
				$('.size-box').slideUp();
			}
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inetpub\vhosts\paneleto.online\api.paneleto.online\resources\views/admin/products/create.blade.php ENDPATH**/ ?>