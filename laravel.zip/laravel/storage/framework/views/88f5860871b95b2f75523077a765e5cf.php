
<?php $__env->startSection('header'); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('src/assets/css/light/scrollspyNav.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('src/assets/css/light/forms/switches.css')); ?>" />

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('src/assets/css/dark/scrollspyNav.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('src/assets/css/dark/forms/switches.css')); ?>" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('panel'); ?>
<div class="middle-content container-xxl p-0">
    
                    <div class="row layout-spacing pt-3">
						<div class="col-lg-12 col-sm-12 col-12 layout-spacing">
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">                                
                                    <div class="row">
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                            <h4>اطلاعات سرویس</h4>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area">
									<form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST" class="row w-100">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
										<div class="col-lg-4 my-auto">
											<label for="name">عنوان محصول</label>
										</div>
										<div class="col-lg-8">
											<div class="input-group mb-3">
                                        		<input type="text" id="name" class="form-control" placeholder="عنوان" name="name" value="<?php echo e($product->name); ?>">
											</div>
										</div>                

										<div class="col-lg-4 my-auto">
											<label for="category">دسته</label>
										</div>
										<div class="col-lg-8">
											<div class="input-group mb-3">
												<select class="form-select " name="category_id" id="category">
													<option disabled selected>دسته</option>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>" <?php echo e($product->category_id == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
											</div>
										</div>
									
										
										<div class="col-lg-4 my-auto">
											<label for="price">قیمت</label>
										</div>
										<div class="col-lg-8">
											<div class="input-group mb-3">
												<input type="text" name="price" value="<?php echo e($product->price); ?>" class="form-control" id="price">
												<span class="input-group-text">تومان</span>
											</div>
										</div>
										<div class="col-lg-4 my-auto">
											<label for="descriptions">توضیحات</label>
										</div>
										<div class="col-lg-8">
											<div class="input-group">
												<textarea class="form-control" name="description"><?php echo e($product->description); ?></textarea>
											</div>
										</div>
										
										<div class="col-lg-4 my-2">
											<button class="btn btn-success mb-2 me-4">ثبت</button>
										</div>
									</form>

                                </div>
                            </div>
                        </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<script src="<?php echo e(asset('assets/js/jquery-3.6.3.min.js')); ?>"></script>
	<script>
		$('#category').on('change',function(){
			if($(this).find(':selected').attr("data-type") == 1){
				$('.size-box').slideDown();
				$('.duration').slideUp();
			} else {
				$('.duration').slideDown();
				$('.size-box').slideUp();
			}
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abolfa35/api.abolfazlabasi.ir/resources/views/admin/products/edit.blade.php ENDPATH**/ ?>