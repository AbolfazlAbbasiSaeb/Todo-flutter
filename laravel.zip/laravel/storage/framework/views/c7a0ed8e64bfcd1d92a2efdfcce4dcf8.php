


<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('panel'); ?>
<div class="middle-content container-xxl p-0">
    
                    <div class="row layout-spacing pt-3">
						<div class="col-lg-12 col-sm-12 col-12 layout-spacing">
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">                                
                                    <div class="row">
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                            <h4>اطلاعات دسته</h4>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area">
									<form class="row w-100" method="POST" action="<?php echo e(route('admin.categories.store')); ?>">
										<?php echo csrf_field(); ?>
										<div class="col-lg-4 my-auto">
											<label for="name">عنوان دسته</label>
										</div>
										<div class="col-lg-4">
											<div class="input-group mb-3">
                                        		<input type="text" id="name" value="<?php echo e(old('name')); ?>" class="form-control" placeholder="عنوان" name="name">
											</div>
										</div>
										<div class="col-lg-4 my-auto">
											<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<span class="text-danger"><?php echo e($message); ?></span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
										<button type="submit" class="btn btn-secondary mb-2 me-4 _effect--ripple waves-effect waves-light">ثبت</button>
									</form>
                                </div>
                            </div>
                        </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abolfa35/api.abolfazlabasi.ir/resources/views/admin/categories/create.blade.php ENDPATH**/ ?>